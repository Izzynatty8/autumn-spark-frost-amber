export type FamilyId =
  | "manuscript"
  | "writing"
  | "formatting"
  | "design"
  | "publishing";

export type StageId =
  | "draft"
  | "shape"
  | "polish"
  | "dress"
  | "bind"
  | "launch";

export type Service = {
  id: string;
  name: string;
  family: FamilyId;
  summary: string;
  body: string;
  related: string[];
  stages: StageId[];
  childrens?: boolean;
};

export type Family = {
  id: FamilyId;
  name: string;
  kicker: string;
  headline: string;
  blurb: string;
};

export type JourneyStage = {
  id: StageId;
  n: string;
  label: string;
  summary: string;
  familyIds: FamilyId[];
};

export type StudioPackage = {
  id: string;
  n: string;
  name: string;
  forWho: string;
  includes: string[];
  serviceIds: string[];
  childrensNote: string;
};

export const families: Family[] = [
  {
    id: "manuscript",
    name: "Manuscript",
    kicker: "Read & revise",
    headline: "Book & manuscript services",
    blurb:
      "The work on the page before anyone sees a cover. We read for story, structure, sentence, and sense — then mark the manuscript so you can decide with a clear head.",
  },
  {
    id: "writing",
    name: "Writing",
    kicker: "Draft & voice",
    headline: "Writing services",
    blurb:
      "When the book still needs a writer in the chair. Ghostwriting, ghost-editing, fiction, and rewriting — always in your name, always from your material.",
  },
  {
    id: "formatting",
    name: "Formatting",
    kicker: "Interior & files",
    headline: "Book formatting & typesetting",
    blurb:
      "The book as an object: type, margins, hierarchy, a table of contents that works, files that upload. Ebook, paperback, hardcover, KDP print and digital.",
  },
  {
    id: "design",
    name: "Design",
    kicker: "Jacket & image",
    headline: "Book design",
    blurb:
      "The face of the book at thumbnail size and in the hand. Front, back, and spine as one object — fiction, nonfiction, and children's, including redesigns.",
  },
  {
    id: "publishing",
    name: "Publishing",
    kicker: "Store & after",
    headline: "Publishing & author support",
    blurb:
      "The last mile: metadata, keywords, KDP upload, and what happens after the book is live. Preparation so you are not learning the dashboard on launch day.",
  },
];

export const journey: JourneyStage[] = [
  {
    id: "draft",
    n: "01",
    label: "Draft",
    summary:
      "Pages exist — or they need to. Alpha reading, ghostwriting, and first-pass story notes.",
    familyIds: ["writing", "manuscript"],
  },
  {
    id: "shape",
    n: "02",
    label: "Shape",
    summary:
      "The book finds its architecture. Developmental and structural editing, character, pacing, argument.",
    familyIds: ["manuscript", "writing"],
  },
  {
    id: "polish",
    n: "03",
    label: "Polish",
    summary:
      "Sentences, grammar, continuity, and the last clean pass. Line, copy, flow, proof.",
    familyIds: ["manuscript"],
  },
  {
    id: "dress",
    n: "04",
    label: "Dress",
    summary:
      "The jacket and the interior as a pair. Cover, spine, children's art direction, typesetting.",
    familyIds: ["design", "formatting"],
  },
  {
    id: "bind",
    n: "05",
    label: "Bind",
    summary:
      "Print-ready and publishing-ready files. Ebook, paperback, hardcover, clickable contents.",
    familyIds: ["formatting"],
  },
  {
    id: "launch",
    n: "06",
    label: "Launch",
    summary:
      "KDP, metadata, upload, and the work after publication. The store page is part of the book.",
    familyIds: ["publishing"],
  },
];

export const services: Service[] = [
  {
    id: "alpha-reading",
    name: "Alpha reading",
    family: "manuscript",
    summary: "An early, honest read while the book is still finding itself.",
    body: "Alpha reading is for drafts you would not yet show a stranger. We read for promise, confusion, and missing load-bearing scenes — then send notes you can act on before you invest in a full edit. Useful when you need a reader, not a rewrite.",
    related: ["beta-reading", "developmental-editing", "character-pacing-story"],
    stages: ["draft", "shape"],
  },
  {
    id: "beta-reading",
    name: "Beta reading",
    family: "manuscript",
    summary: "A late-draft reader report from someone who finishes books for a living.",
    body: "Beta reading sits after you think you are close. We read as a careful stranger: where we stalled, who we believed, what we would tell a friend. You receive a structured report — not a vague 'I liked it' — so the next pass has a map.",
    related: ["alpha-reading", "manuscript-review", "character-pacing-story"],
    stages: ["shape", "polish"],
  },
  {
    id: "book-editing",
    name: "Book editing",
    family: "manuscript",
    summary: "A sequenced edit, not a single sweep with five names on it.",
    body: "Book editing at the studio is a plan: which pass the manuscript actually needs, in which order, and what 'done' will look like. Developmental or structural work first when the bones are wrong; line and copy when the bones are right. Quoted after a sample.",
    related: ["developmental-editing", "line-editing", "copy-editing", "proofreading"],
    stages: ["shape", "polish"],
  },
  {
    id: "developmental-editing",
    name: "Developmental editing",
    family: "manuscript",
    summary: "The book you meant to write, seen from above.",
    body: "Developmental editing looks at structure, argument or plot, character (or through-line), and whether chapters earn their place. You receive an editorial letter and an annotated manuscript — not a vibe. Fiction, memoir, and idea-driven nonfiction all live here.",
    related: ["structural-editing", "character-pacing-story", "rewriting", "ghost-editing"],
    stages: ["shape"],
    childrens: true,
  },
  {
    id: "structural-editing",
    name: "Structural editing",
    family: "manuscript",
    summary: "Order, proportion, and the joints between parts.",
    body: "Structural editing is architecture. We move, cut, and re-sequence so the reader is never doing the author's filing. Especially useful for nonfiction, books built from talks or blogs, and novels whose middle has gone slack.",
    related: ["developmental-editing", "rewriting", "manuscript-review"],
    stages: ["shape"],
  },
  {
    id: "character-pacing-story",
    name: "Character, pacing & story feedback",
    family: "manuscript",
    summary: "Who we follow, how fast we move, and why we stay.",
    body: "A focused letter on character want, viewpoint, scene purpose, and pace. We mark the pages where the story goes quiet or a person stops being themselves. Picture books get the same seriousness: page-turns are structure.",
    related: ["developmental-editing", "beta-reading", "fiction-writing"],
    stages: ["draft", "shape"],
    childrens: true,
  },
  {
    id: "line-editing",
    name: "Line editing",
    family: "manuscript",
    summary: "The sentence as the unit of the book.",
    body: "Line editing works at the level of rhythm, image, and voice. We keep your diction and remove the fog: stacked metaphors, throat-clearing, dialogue that explains what the scene already showed. The book should still sound like you on the far side.",
    related: ["grammar-clarity-flow", "copy-editing", "ghost-editing"],
    stages: ["polish"],
    childrens: true,
  },
  {
    id: "copy-editing",
    name: "Copy editing",
    family: "manuscript",
    summary: "Correct, consistent, and quiet on the page.",
    body: "Copy editing catches grammar, usage, continuity, and house style so the reader never trips on the machinery. Names, timelines, hyphenation, captions, headings — the unglamorous work that makes a book feel finished.",
    related: ["grammar-clarity-flow", "proofreading", "line-editing"],
    stages: ["polish"],
  },
  {
    id: "grammar-clarity-flow",
    name: "Grammar, clarity & flow editing",
    family: "manuscript",
    summary: "When the idea is right and the English is in the way.",
    body: "A clarity pass for authors writing in a second language, or in a hurry. We keep meaning, smooth syntax, and mark anything a copy editor would still need to see. English, with care for voice that began in Yoruba, French, or Spanish.",
    related: ["copy-editing", "line-editing", "rewriting"],
    stages: ["polish"],
  },
  {
    id: "proofreading",
    name: "Proofreading",
    family: "manuscript",
    summary: "The last clean pass on laid-out pages.",
    body: "Proofreading happens after typesetting, not instead of editing. We read the designed pages for typos, bad breaks, numbering, and the errors that only appear once type is set. If the manuscript is still moving, this is not the service yet.",
    related: ["copy-editing", "typesetting", "print-ready"],
    stages: ["polish", "bind"],
  },
  {
    id: "manuscript-review",
    name: "Manuscript review & feedback",
    family: "manuscript",
    summary: "A diagnostic when you do not yet know which edit you need.",
    body: "A manuscript review is a letter, not a full markup: strengths, risks, and a recommended path (sample, developmental, line, or 'you are closer than you think'). The right next step is the whole point of this studio.",
    related: ["book-editing", "beta-reading", "developmental-editing"],
    stages: ["draft", "shape"],
  },
  {
    id: "ghostwriting",
    name: "Ghostwriting",
    family: "writing",
    summary: "We write. Your name stays on the cover.",
    body: "Ghostwriting is drafting from your notes, interviews, outline, or recordings, in a voice we build with you. You remain the author. Scope is quoted after a sample chapter so neither of us is guessing at length or tone.",
    related: ["ghost-editing", "fiction-writing", "book-content", "rewriting"],
    stages: ["draft"],
  },
  {
    id: "ghost-editing",
    name: "Ghost-editing",
    family: "writing",
    summary: "Heavier than an edit, lighter than a ghostwrite.",
    body: "Ghost-editing is for manuscripts that have a true core and a voice that still needs a writer beside it. We recast scenes and chapters, keep what only you could have said, and hand back a draft that can take a line edit.",
    related: ["ghostwriting", "rewriting", "developmental-editing", "line-editing"],
    stages: ["draft", "shape"],
  },
  {
    id: "fiction-writing",
    name: "Fiction writing",
    family: "writing",
    summary: "Stories written to be published, not to fill a page count.",
    body: "Original fiction — in collaboration or from a brief. Short stories, novellas, and novel-length work. We agree voice, genre promise, and length before a word is billed. You own the work.",
    related: ["short-stories-novels", "ghostwriting", "character-pacing-story"],
    stages: ["draft"],
  },
  {
    id: "short-stories-novels",
    name: "Short stories & novels",
    family: "writing",
    summary: "Length is a craft choice, not a default.",
    body: "We write and develop both short fiction and full-length novels, including series bibles and the connective tissue between books. If the idea is a short story trying to be a novel (or the reverse), we will say so.",
    related: ["fiction-writing", "ebooks", "developmental-editing"],
    stages: ["draft", "shape"],
  },
  {
    id: "ebooks",
    name: "Ebooks",
    family: "writing",
    summary: "Books meant to live digitally, written with that in mind.",
    body: "Ebook writing is not print copy pasted into a file. We plan chapters, headings, and calls-to-action for the way people actually read on a phone — then hand the draft to formatting so the file matches the intention.",
    related: ["book-content", "ebook-formatting", "kdp-ebook-formatting"],
    stages: ["draft", "bind"],
  },
  {
    id: "book-content",
    name: "Book content writing",
    family: "writing",
    summary: "Chapters, front matter, and the words around the story.",
    body: "Forewords, about-the-author, chapter openers, workbooks, and the pages that sit beside the main text. Small in the contents list, large in how professional the book feels.",
    related: ["ghostwriting", "ebooks", "rewriting"],
    stages: ["draft", "polish"],
  },
  {
    id: "rewriting",
    name: "Rewriting & content improvement",
    family: "writing",
    summary: "Keep the thinking. Rebuild the pages.",
    body: "Rewriting is for manuscripts with good material buried in them: talks, notes, a first draft in another language, a book that grew without a spine. We re-outline, rewrite, and leave you a manuscript a line editor can love.",
    related: ["ghost-editing", "structural-editing", "grammar-clarity-flow"],
    stages: ["draft", "shape"],
  },
  {
    id: "ebook-formatting",
    name: "Ebook formatting",
    family: "formatting",
    summary: "Reflowable files that behave on a phone and an e-ink screen.",
    body: "Clean heading structure, working navigation, images that scale, and no leftover Word wreckage. Delivered as EPUB and, where needed, KPF — whatever you asked for in the brief.",
    related: ["kdp-ebook-formatting", "clickable-toc", "ebook-cover"],
    stages: ["bind"],
  },
  {
    id: "kdp-ebook-formatting",
    name: "KDP ebook formatting",
    family: "formatting",
    summary: "Files that match what Amazon's dashboard actually accepts.",
    body: "KDP ebook formatting is ebook craft plus the platform's habits: covers at the right ratio, TOC rules, and a preview that does not surprise you on a Kindle. We format, then stay through the upload if you want a hand.",
    related: ["ebook-formatting", "kdp-support", "book-upload"],
    stages: ["bind", "launch"],
  },
  {
    id: "kdp-print-formatting",
    name: "KDP print formatting",
    family: "formatting",
    summary: "Trim size, margins, and a spine that meets in the middle.",
    body: "Print-on-demand is unforgiving about bleed, gutter, and fonts that only looked fine on a laptop. We build the interior to KDP's template for your trim, with a spine width that matches page count.",
    related: ["paperback-formatting", "hardcover-formatting", "print-ready"],
    stages: ["bind", "launch"],
  },
  {
    id: "paperback-formatting",
    name: "Paperback formatting",
    family: "formatting",
    summary: "A trade paperback that feels designed, not dumped.",
    body: "Chapter openers, running heads, folios, and type that can be read in a chair. We choose a text face that suits the book, not a default, and we proof the PDF at 100% before you see 'print-ready'.",
    related: ["hardcover-formatting", "typesetting", "interior-design"],
    stages: ["bind"],
  },
  {
    id: "hardcover-formatting",
    name: "Hardcover formatting",
    family: "formatting",
    summary: "Case laminate or jacketed — interiors that justify the boards.",
    body: "Hardcover files need different rims, sometimes different front matter, and a spine that will be seen on a shelf. We prepare interiors and, with design, the wrap that goes around them.",
    related: ["paperback-formatting", "spine-design", "print-ready"],
    stages: ["bind"],
  },
  {
    id: "interior-design",
    name: "Interior book design",
    family: "formatting",
    summary: "The page as a composed surface, not a Word theme.",
    body: "Ornaments used once, hierarchy that teaches the reader how to move, and special pages (maps, recipes, plates, picture-book spreads) treated as design, not afterthoughts. Children's interiors are paced for the turn.",
    related: ["typesetting", "childrens-design", "paperback-formatting"],
    stages: ["dress", "bind"],
    childrens: true,
  },
  {
    id: "typesetting",
    name: "Typesetting & layout",
    family: "formatting",
    summary: "Letters in the right relationship to each other.",
    body: "Tracking, hyphenation, rivers, widows, stacked hyphenation — the work readers only notice when it is wrong. We typeset in InDesign, Vellum, or Atticus according to the book, then export the formats you named.",
    related: ["interior-design", "proofreading", "print-ready"],
    stages: ["dress", "bind"],
  },
  {
    id: "clickable-toc",
    name: "Clickable table of contents",
    family: "formatting",
    summary: "Navigation that works, in the file and in the store preview.",
    body: "A clickable contents is a heading structure, not a decoration. We build it so Kindle, Apple Books, and print contents pages agree with each other — including nested parts and back matter.",
    related: ["ebook-formatting", "kdp-ebook-formatting"],
    stages: ["bind"],
  },
  {
    id: "print-ready",
    name: "Print-ready & publishing-ready files",
    family: "formatting",
    summary: "The packet you actually upload.",
    body: "Print PDF with correct bleed and fonts outlined or embedded, EPUB, KPF, cover PNG or PDF, and InDesign or source files when requested. Named, checked, and listed so you are not guessing which file is the file.",
    related: ["kdp-print-formatting", "book-upload", "proofreading"],
    stages: ["bind", "launch"],
  },
  {
    id: "cover-design",
    name: "Book cover design",
    family: "design",
    summary: "One job: the right reader, at thumbnail size.",
    body: "We design from genre promise, not from a moodboard of unrelated bestsellers. Typography, image, and color do the talking. You receive ebook and print treatments that belong to the same book.",
    related: ["spine-design", "ebook-cover", "cover-redesign"],
    stages: ["dress"],
    childrens: true,
  },
  {
    id: "cover-redesign",
    name: "Cover redesign",
    family: "design",
    summary: "When the book has outgrown the jacket it launched in.",
    body: "A redesign is not a louder version of the old file. We look at what the book actually is now, who it failed to attract, and build a new face — useful after a series shift, a new edition, or a cover that never earned its thumbnail.",
    related: ["cover-design", "fiction-nonfiction-covers"],
    stages: ["dress", "launch"],
  },
  {
    id: "spine-design",
    name: "Front, back & spine design",
    family: "design",
    summary: "The wrap is one object. The spine is a billboard.",
    body: "Back-cover copy hierarchy, barcode clearance, and a spine that reads from a shelf — including the math of page count. We deliver a full wrap, not a front we hope will stretch.",
    related: ["cover-design", "hardcover-formatting", "kdp-print-formatting"],
    stages: ["dress", "bind"],
  },
  {
    id: "fiction-nonfiction-covers",
    name: "Fiction & nonfiction covers",
    family: "design",
    summary: "Different promises. Different visual grammar.",
    body: "Fiction covers sell a feeling and a contract with genre. Nonfiction covers sell a claim the reader can repeat. We do not put a thriller jacket on a memoir, or a stock handshake on a book that has a real idea.",
    related: ["cover-design", "ebook-cover"],
    stages: ["dress"],
  },
  {
    id: "childrens-design",
    name: "Children's book design",
    family: "design",
    summary: "Pictures, type, and page-turns as one instrument.",
    body: "Picture books, chapter books, and middle grade each have their own rules for type size, contrast, and how much the image is allowed to speak. We design covers and interiors together so the child and the adult who buys the book are both told the truth.",
    related: ["cover-design", "interior-design", "character-pacing-story"],
    stages: ["dress", "bind"],
    childrens: true,
  },
  {
    id: "ebook-cover",
    name: "Ebook cover design",
    family: "design",
    summary: "A jacket that still works at the size of a stamp.",
    body: "Ebook covers are cropped, compressed, and seen in a grid. We design for that first, then derive the print wrap — not the other way around. KDP's current size rules are part of the brief, not an afterthought.",
    related: ["cover-design", "kdp-ebook-formatting"],
    stages: ["dress", "launch"],
  },
  {
    id: "canva-design",
    name: "Canva book design",
    family: "design",
    summary: "When the handoff needs to stay editable.",
    body: "Some authors want files they can still touch. We design in Canva when that is the right tool, with locked hierarchy and export settings that survive a later edit — and we will say when InDesign or Photoshop is the honest choice instead.",
    related: ["cover-design", "interior-design"],
    stages: ["dress"],
    childrens: true,
  },
  {
    id: "kdp-support",
    name: "Amazon KDP publishing support",
    family: "publishing",
    summary: "A calm walk through a dashboard that is not calm.",
    body: "Categories, keywords, pricing, territories, ISBN choices, proof copies. We sit with you (or for you) so the book you made is the book that goes live. You remain the publisher of record.",
    related: ["book-upload", "metadata", "manuscript-to-publishing"],
    stages: ["launch"],
  },
  {
    id: "manuscript-to-publishing",
    name: "Manuscript-to-publishing preparation",
    family: "publishing",
    summary: "A checklist with a person attached.",
    body: "The gap between 'the Word file is done' and 'the book exists' is where projects stall. We build the packet: edited text, interior, wrap, descriptions, and a launch order of operations — then stay through upload.",
    related: ["kdp-support", "print-ready", "book-editing"],
    stages: ["bind", "launch"],
  },
  {
    id: "book-upload",
    name: "Book upload & formatting assistance",
    family: "publishing",
    summary: "The hour on the dashboard, done once, done right.",
    body: "We prepare or perform the upload, preview every device Amazon shows you, and fix the surprises (fonts, TOC, cover ratio) before readers do. Paperback and hardcover follow the same pass.",
    related: ["kdp-ebook-formatting", "kdp-print-formatting", "kdp-support"],
    stages: ["launch"],
  },
  {
    id: "metadata",
    name: "Book metadata & keywords",
    family: "publishing",
    summary: "The words that help the right stranger find the book.",
    body: "Title, subtitle, description, BISAC, keywords, and the first three lines that show in a store. Written to be true and searchable — not stuffed. The cover and the metadata should tell the same story.",
    related: ["kdp-support", "post-pub-marketing", "cover-design"],
    stages: ["launch"],
  },
  {
    id: "post-pub-marketing",
    name: "Post-publication book marketing",
    family: "publishing",
    summary: "After the book is live, it still needs a plan.",
    body: "A practical stretch: listing hygiene, a simple content rhythm, launch-week assets, and what is worth doing versus what only looks busy. We do not promise lists we do not have. We do make the book easier to talk about.",
    related: ["metadata", "author-platform", "cover-redesign"],
    stages: ["launch"],
  },
  {
    id: "author-platform",
    name: "Author platform & website support",
    family: "publishing",
    summary: "A home for the work that is not only a store page.",
    body: "A modest, professional author site: books, bio, mail sign-up, press. We help you say what the books are without turning the page into a billboard. Useful whether you have one title or a small shelf.",
    related: ["post-pub-marketing", "metadata"],
    stages: ["launch"],
  },
];

export const packages: StudioPackage[] = [
  {
    id: "story-foundation",
    n: "01",
    name: "Story Foundation",
    forWho: "For drafts that are not yet a book.",
    includes: [
      "Alpha or beta reading",
      "Developmental or structural editing",
      "Character, pacing, and story feedback",
    ],
    serviceIds: [
      "alpha-reading",
      "beta-reading",
      "developmental-editing",
      "structural-editing",
      "character-pacing-story",
    ],
    childrensNote: "Picture-book dummies and chapter books: we read for page-turn and age.",
  },
  {
    id: "prose-polish",
    n: "02",
    name: "Prose Polish",
    forWho: "For manuscripts whose story is in place.",
    includes: [
      "Line editing",
      "Copy editing",
      "Grammar, clarity, and flow",
      "Proofreading on request after layout",
    ],
    serviceIds: [
      "line-editing",
      "copy-editing",
      "grammar-clarity-flow",
      "proofreading",
    ],
    childrensNote: "Read-aloud rhythm and type size are part of the polish, not extras.",
  },
  {
    id: "ghosted-guided",
    n: "03",
    name: "Ghosted & Guided",
    forWho: "For authors who need the pages written or rebuilt.",
    includes: [
      "Ghostwriting or ghost-editing",
      "Fiction, short stories, novels, ebooks",
      "Rewriting and content improvement",
    ],
    serviceIds: [
      "ghostwriting",
      "ghost-editing",
      "fiction-writing",
      "short-stories-novels",
      "ebooks",
      "book-content",
      "rewriting",
    ],
    childrensNote: "We can draft from a dummy, an outline, or a story you tell out loud.",
  },
  {
    id: "bound-page",
    n: "04",
    name: "The Bound Page",
    forWho: "For authors who need a real interior.",
    includes: [
      "Ebook and KDP ebook formatting",
      "Paperback and hardcover interiors",
      "Typesetting, clickable TOC, print-ready files",
    ],
    serviceIds: [
      "ebook-formatting",
      "kdp-ebook-formatting",
      "kdp-print-formatting",
      "paperback-formatting",
      "hardcover-formatting",
      "interior-design",
      "typesetting",
      "clickable-toc",
      "print-ready",
    ],
    childrensNote: "Illustrated interiors: image placement, bleed, and type that children can actually read.",
  },
  {
    id: "jacket-cover",
    n: "05",
    name: "Jacket & Cover",
    forWho: "For authors who need the face of the book.",
    includes: [
      "Cover design or redesign",
      "Front, back, and spine",
      "Ebook, print, and children's treatments",
    ],
    serviceIds: [
      "cover-design",
      "cover-redesign",
      "spine-design",
      "fiction-nonfiction-covers",
      "childrens-design",
      "ebook-cover",
      "canva-design",
    ],
    childrensNote: "Picture-book jackets designed with the interior, not as a sticker on the front.",
  },
  {
    id: "imprint-launch",
    n: "06",
    name: "Imprint Launch",
    forWho: "For authors ready to go live.",
    includes: [
      "KDP publishing support",
      "Upload and formatting assistance",
      "Metadata, keywords, and post-publication support",
    ],
    serviceIds: [
      "kdp-support",
      "manuscript-to-publishing",
      "book-upload",
      "metadata",
      "post-pub-marketing",
      "author-platform",
    ],
    childrensNote: "Categories and keywords that reach parents and teachers, not only 'juvenile fiction'.",
  },
  {
    id: "full-imprint",
    n: "07",
    name: "Full Imprint",
    forWho: "For authors who want one studio from draft to store.",
    includes: [
      "The whole pipeline, quoted as one engagement",
      "Editing, writing as needed, design, formatting, KDP",
      "A single brief, a single roster, two revision rounds at each stage",
    ],
    serviceIds: services.map((s) => s.id),
    childrensNote: "A picture book or middle-grade title can run the full path without changing rooms.",
  },
];

export const tools = [
  "Microsoft Word (Track Changes)",
  "Google Docs",
  "Vellum",
  "Atticus",
  "Adobe InDesign",
  "Canva",
  "Kindle Create",
  "Photoshop",
] as const;

export const deliverables = [
  "Edited .docx",
  "Print PDF",
  "KPF",
  "EPUB",
  "Cover PNG / PDF",
  "InDesign or source files on request",
] as const;

export const processSteps = [
  {
    n: "01",
    title: "Brief",
    body: "You send the manuscript brief — where you are, what you have, when you need it. We reply within 1–2 hours.",
  },
  {
    n: "02",
    title: "Sample or scope",
    body: "A free first-1,000-word sample, or a written plan if you already know the work. Either way, you see how we think before you commit.",
  },
  {
    n: "03",
    title: "Agreement",
    body: "Scope, timeline, and files named. Two rounds of revision are included. You remain the author and the publisher of record.",
  },
  {
    n: "04",
    title: "The work",
    body: "Edits in Word or Google Docs. Interiors in Vellum, Atticus, or InDesign. Covers in Photoshop, InDesign, or Canva — whichever the book needs.",
  },
  {
    n: "05",
    title: "Handoff",
    body: "The formats you asked for: edited .docx, print PDF, KPF, EPUB, cover PNG or PDF, source files if requested.",
  },
  {
    n: "06",
    title: "Optional launch",
    body: "KDP upload, metadata, and the quiet work after publication. Only if you want us in that room.",
  },
] as const;

export const testimonials = [
  {
    quote:
      "I sent a draft I was half-ashamed of. The structural letter named the book I thought I had written and the one on the page. Three weeks later I had something I would put my name on.",
    name: "N.",
    role: "Independent novelist",
    lane: "Fiction",
  },
  {
    quote:
      "They treated the interior like the cover's quieter twin. Print files uploaded on the first try. I had been dreading the dashboard; it took an afternoon.",
    name: "K.",
    role: "Nonfiction author",
    lane: "Nonfiction",
  },
  {
    quote:
      "Our picture book's pacing finally matched the page turns. The notes were kind and exact — not 'make it funnier,' but which spread was carrying too much story.",
    name: "M.",
    role: "Children's author-illustrator",
    lane: "Children's",
  },
  {
    quote:
      "I had been stuck at almost-done for a year. The line edit and the KDP handoff were the same conversation. That was the difference. Title withheld, as agreed.",
    name: "S.",
    role: "Genre novelist",
    lane: "Fiction",
  },
] as const;

export const covers = [
  {
    src: "/images/cover-river.jpg",
    title: "Where the River Keeps Its Name",
    lane: "Literary fiction · cover direction",
    note: "Studio sample. Not a client title.",
  },
  {
    src: "/images/cover-hare.jpg",
    title: "The Lantern Under the Baobab",
    lane: "Picture book · cover direction",
    note: "Studio sample. Not a client title.",
  },
] as const;

export const faqs = [
  {
    q: "How does the free 1,000-word sample work?",
    a: "Send the brief and tell us you want a sample. We reply within 1–2 hours with where to send the excerpt. You get a marked passage and a short note on what the rest of the manuscript likely needs — no obligation.",
  },
  {
    q: "Why are there no prices on the site?",
    a: "Length, genre, language, draft stage, and deadline change the work. We quote after the brief, usually the same day. If the fit is wrong, we will say so rather than stretch a number.",
  },
  {
    q: "Do I stay the author?",
    a: "Yes. Ghostwritten or ghost-edited books go out under your name. You remain the publisher of record on KDP. The studio does not take a credit line unless you ask for one.",
  },
  {
    q: "What will I receive?",
    a: "Whatever you requested in the brief: edited .docx, print PDF, KPF, EPUB, cover PNG or PDF, and source files when that is part of the work. Two rounds of revision are included.",
  },
  {
    q: "Can you work on children's books and adult books?",
    a: "Yes. Fiction, nonfiction, and children's are three lanes in the same studio. Use Children's mode on this site if you want the picture-book pathway in front.",
  },
  {
    q: "Which languages do you work in?",
    a: "English, Yoruba, French, and Spanish. Manuscripts may be written in one and published in another; say so in the brief so we quote the right pass.",
  },
  {
    q: "Is my manuscript confidential?",
    a: "Yes. We do not list client titles here. If you need a written NDA before you send pages, say so in the brief.",
  },
  {
    q: "How fast do you reply?",
    a: "Within 1–2 hours, from West Africa Time. The work itself is quoted with a calendar, not a promise pulled from the air.",
  },
  {
    q: "What tools do you use?",
    a: "Word with Track Changes, Google Docs, Vellum, Atticus, InDesign, Canva, Kindle Create, and Photoshop. We pick the tool that matches the file you need, not the one that is fashionable.",
  },
];

export function familyById(id: FamilyId) {
  return families.find((f) => f.id === id)!;
}

export function serviceById(id: string) {
  return services.find((s) => s.id === id);
}

export function servicesForFamily(id: FamilyId) {
  return services.filter((s) => s.family === id);
}

export function servicesForStage(id: StageId) {
  return services.filter((s) => s.stages.includes(id));
}

export function packageById(id: string) {
  return packages.find((p) => p.id === id);
}

export const familyLinks: Record<FamilyId, FamilyId[]> = {
  manuscript: ["writing", "design", "formatting"],
  writing: ["manuscript", "formatting"],
  formatting: ["design", "publishing", "manuscript"],
  design: ["formatting", "publishing", "manuscript"],
  publishing: ["formatting", "design"],
};

export const draftStages = [
  { value: "idea", label: "Idea / outline only" },
  { value: "messy", label: "Messy first draft" },
  { value: "revised", label: "Revised manuscript" },
  { value: "line-ready", label: "Ready for line or copy edit" },
  { value: "format-ready", label: "Text locked, needs design or files" },
  { value: "formatted", label: "Formatted files, needs upload or proof" },
] as const;

export const audienceOptions = [
  { value: "fiction", label: "Adult fiction" },
  { value: "nonfiction", label: "Adult nonfiction" },
  { value: "childrens", label: "Children's / middle grade" },
  { value: "mixed", label: "More than one" },
] as const;

export const formatOptions = [
  { value: "kdp-ebook", label: "KDP ebook" },
  { value: "paperback", label: "Paperback" },
  { value: "hardcover", label: "Hardcover" },
  { value: "wide-ebook", label: "Wide ebook (EPUB)" },
  { value: "unsure", label: "Not sure yet" },
] as const;

export const haveOptions = [
  { value: "nothing", label: "Just the manuscript (or less)" },
  { value: "cover", label: "A cover" },
  { value: "isbn", label: "An ISBN" },
  { value: "interior", label: "Interior files" },
  { value: "account", label: "A KDP account" },
] as const;
